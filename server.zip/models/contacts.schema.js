const mongoose = require('mongoose');

const contactSchema = mongoose.Schema({
    userId:{
        type:mongoose.Schema.Types.ObjectId,
        ref:('users')
    },
    contactName:{
        type:String,
        required:true
    },
    contactNumber:{
        type:String,
        require:true
    }
})

module.exports =  mongoose.model('contacts',contactSchema);
