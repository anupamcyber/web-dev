const jwt = require('jsonwebtoken');
const secretKey = "contactlogproject";

const auth = async (req,res,next)=>{
    if(req.header('x-auth-token')){
        const token = req.header('x-auth-token')
        try{
            await jwt.verify(token,secretKey);
            next();
        }catch(err){
            res.status(401).json({
                message:"Unauthorised Request!!! Bad token"
            })
        }
    }
    else{
        res.status(401).json({
            message:"Unauthorised Request!!! Token Missing"
        })
    }
}

module.exports = auth