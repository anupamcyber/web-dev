const config = {
    uri:'mongodb+srv://1234silicon:<1234silicon>@cluster0.y74fa.mongodb.net/ContactManager?retryWrites=true&w=majority'


    
}

module.exports = config;