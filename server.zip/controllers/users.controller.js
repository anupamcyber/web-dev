const users = require('../models/users.schema');
const bcryptjs = require('bcryptjs');
const joi = require('joi');
const jwt = require('jsonwebtoken');
const secretKey = "contactlogproject"

exports.registration = async (req,res)=>{
    const userValidateSchema = joi.object({
        name:joi.string().pattern(new RegExp('^[a-zA-Z ]{3,30}$')).required(),
        email:joi.string().email().required(),
        password:joi.string().pattern(new RegExp('^[a-zA-Z0-9]{6,12}$')).required(),
        confirmPassword:joi.ref('password')
    })
    try{
        let userFields = await userValidateSchema.validateAsync(req.body);
        
        let user = await users.findOne({email:userFields.email});

        if(!user){
            user = new users(userFields)
            const salt = await bcryptjs.genSalt(10);
            user.password = await bcryptjs.hash(user.password,salt)
            await user.save();
            res.status(200).json({
                message:"User information saved successfully",
                savedUser:user
            })
        }
        else{
            res.status(200).json({
                message:"Author already exists",
            })
        }
    }catch(err){
        res.status(400).json({
            message:"Something went wrong while registering",
            
            error:err
        })
    }
}

exports.login = async (req,res)=>{
    const loginSchema = joi.object({
        email:joi.string().required(),
        password:joi.string().required()
    })

    try{
        const loginFields = await loginSchema.validateAsync(req.body);
        //console.log(loginFields);

        let user = await users.findOne({email:loginFields.email})
        //console.log(user);

        if(!user){
            res.status(400).json({
                message:"Username/Password doesn't exist"
            })
        }
        else{
            const is_match = await bcryptjs.compare(loginFields.password,user.password)
            //console.log(is_match);
            if(!is_match){
                res.status(400).json({
                    message:"Username/Password doesn't existssss"
                })
            }
            else{
                const payload={
                    userData:{
                        id:user._id
                    }
                }
                const token = await jwt.sign(payload,secretKey,{expiresIn:7200})
                res.status(200).json({
                    message:"Logged-In",
                    user:{id:user._id,name:user.name},
                    token
                })
            }
        }
    }catch(err){
        res.status(400).json({
            message:"Something went wrong in Log-In",
            error:err
        })
    }
}