const contacts = require('../models/contacts.schema');
const { post } = require('../routes/users.routes');

exports.contactslist = async (req,res)=>{
    try{
        let list = await contacts.find().populate('userId');
        if(!list){
            list=[]
        }
        res.status(200).json({
            message:"List fetched successfully",
            contactsList:list
        })
    }catch(err){
        res.status(500).json({
            message:"something went wrong",
            error:err
        })
    }
}

exports.addContacts = async (req,res)=>{
    const contactObj={
        userId:req.body.uid,
        contactName:req.body.cname,
        contactNumber:req.body.cnum
    }
    try{
        const newContact = new contacts(contactObj);
        await newContact.save()
        res.status(200).json({
            message:"Player details saved successfully",
            savedContact:newContact
        })
    }catch(err){
        res.status(500).json({
            message:"Something went wrong!",
            error:err
        })
    } 
}

exports.updateContacts = async (req,res)=>{
    const id = req.params.id;
    const contactsObj={
        userId:req.body.uid,
        contactName:req.body.cname,
        contactNumber:req.body.cnum
    }
    try{
        const updateContact = await contacts.findByIdAndUpdate(id,{$set:contactsObj});
        console.log(updateContact);
        
        if(updateContact == null){
            res.status(400).json({
                message:"Id not found for updation"
            })
        }
        else{
            res.status(200).json({
                message:"Contact updated successfully",
                updateContact:updateContact
            })
        }
    }catch(err){
        res.status(500).json({
            message:"Something went wrong in update!",
            erroe:err
        })
    }
}

exports.deleteContacts = async (req,res)=>{
    const id = req.params.id;
    const deleteContact = await contacts.findByIdAndDelete(id);

    try{
        if(deleteContact == null){
            res.status(400).json({
                message:"Id not found for Deletion"
            })
        }
        else{
            res.status(200).json({
                message:"Id deleted successfully"
            })
        }
    }catch(err){
        res.status(500).json({
            message:"Something went wrong in delete!"
        })
    }

}
exports.getContactsbyUser = async (req,res)=>{
    try{
        let list = await contacts.find({userId:req.params.userId});
        if(!list){
            list = [];
        }
        res.status(200).json({
            message:"Contact list of a user",
            contactList:list
        })
    }catch(err){
        res.status(400).json({
            message:"Something went wrong while showing contacts of a user",
            error:err
        })
    }
}