const express = require('express');
const route = express.Router();
const usersController = require('../controllers/users.controller')

route.post("/register",usersController.registration);
route.post("/login",usersController.login);

module.exports = route;