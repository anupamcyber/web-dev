const express = require('express');
const route = express.Router();
const contactsController = require('../controllers/contacts.controller');

route.post("/save",contactsController.addContacts);
route.put("/update/:id",contactsController.updateContacts);
route.delete("/delete/:id",contactsController.deleteContacts);
route.get("/getofuser/:userId",contactsController.getContactsbyUser);
route.get("/",contactsController.contactslist);

module.exports = route;