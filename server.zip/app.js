const { json } = require('express');
const express = require('express');
const contactRoutes = require('./routes/contacts.routes');
const userRoutes = require('./routes/users.routes')
const dbconnect = require('./config/db.connect');
const port = process.env.PORT || 3000;

const app = express();

app.use(express.json());
app.use('/api/contacts',contactRoutes);
app.use('/api/users',userRoutes);

dbconnect();

app.listen(port,()=>{
    console.log(`Server started at port ${port}`);
})